create function tinggi_max() returns integer
    language plpgsql
as
$$
declare tertinggi integer;
begin
select max(tinggi) into tertinggi from postgres;
return tertinggi;
end
$$;

alter function tinggi_max() owner to postgres;

